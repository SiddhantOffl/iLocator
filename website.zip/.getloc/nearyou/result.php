<?php
header('Content-Type: text/html');
{
  $lat = $_POST['Lat'];
  $lon = $_POST['Lon'];


  $data['info'] = array();

  $data['info'][] = array(
    'lat' => $lat,
    'lon' => $lon,
    );

  $jdata = json_encode($lat);
  $vi = "\nLAN: ";
  $vii = "\nLON: ";
  $jdata2 = json_encode($lon);

  $f = fopen('result.json', 'w+');
  fwrite($f, $vi);
  fwrite($f, $lat);
  fwrite($f, $vii);
  fwrite($f, $lon);
  fclose($f);
}
?>
